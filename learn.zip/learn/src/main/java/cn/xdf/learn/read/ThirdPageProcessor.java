package cn.xdf.learn.read;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;

/**
 * @author sunxingyang<br>
 */
public class ThirdPageProcessor implements PageProcessor {

	private Site site = Site.me().setSleepTime(500).setRetryTimes(100)
			.setTimeOut(15000);
	public void process(Page page) {
		//试题部分
		String questionContent = "//div[@class='i-question-type-fullcol']/div[@class='question-body g-clearfix']/div[@class='question-col js-translate-content']";
		
		//题目
		String questionTitle = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/h3[1]").toString().substring(27).replace("</h3>", "");
		System.out.println(questionTitle);
		//选项
		String item1 = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/div[@class='question-form']/ul[1]/li[1]/text()").toString();
		System.out.println("选项");
		System.out.println(item1);
		String item2 = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/div[@class='question-form']/ul[1]/li[2]/text()").toString();
		System.out.println(item2);
		String item3 = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/div[@class='question-form']/ul[1]/li[3]/text()").toString();
		System.out.println(item3);
		String item4 = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/div[@class='question-form']/ul[1]/li[4]/text()").toString();
		System.out.println(item4);
		//正确答案
		String answer = page
				.getHtml()
				.xpath(questionContent+"/div[@class='inner']/div[@class='bottom-side']/div[1]/span[1]/b[1]/text()").toString().trim();
		System.out.println("正确答案："+answer);
		//题目解析
		String timuAnalysis = page
				.getHtml()
				.xpath("//div[@class='g-kmf-wrapper']/div[@class='g-clearfix']/div[@class='kmf-maincol']/div[@class='s-analyse']/div[@class='i-toelf-subject-analyze']/div[@class='js-analysis-container']/div[1]/div[2]/text()").toString();
		
		System.out.println("题目解析"+timuAnalysis);
	}

	public Site getSite() {
		return site;

	}

}
