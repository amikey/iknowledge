package cn.xdf.learn.read;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

/**
 * @author sunxingyang<br>
 */
public class SecondPageProcessor implements PageProcessor {

	private Site site = Site.me().setSleepTime(500).setRetryTimes(100)
			.setTimeOut(15000);
	public void process(Page page) {
		String content = "//div[@class='i-question-type-fullcol']/div[@class='question-body g-clearfix']/div[@class='stuff-col']\n" + 
				"/div[@class='stuff-content']";
		//阅读英文
		String contentEn = page
				.getHtml()
				.xpath(content+"/div[@class='inner js-article']/p[1]").toString().substring(40).replace("</p>", "");
		System.out.println(contentEn);
		//阅读译文
		String contentCn = page
				.getHtml()
				.xpath(content+"/div[2]/p[1]").toString().substring(19).replace("</p>", "");
		//试题部分
		String questionContent = "//div[@class='i-question-type-fullcol']/div[@class='question-body g-clearfix']/div[@class='question-col js-translate-content']";
		//题目编号
		StringBuffer questionNums = new StringBuffer();
		for (int i = 1; i <= 13; i++) {
			questionNums.append(page
				.getHtml()
				.xpath(questionContent+"/div[@class='tab-question']/div[@class='list js-container']/div[1]/a["+i+"]/@href").toString());
			questionNums.append(",");
		}
		String[] qns = questionNums.toString().split(",");
		for (String string : qns) {
			Spider.create(new ThirdPageProcessor())
			.addUrl(string).run();
		}
	}

	public Site getSite() {
		return site;

	}


}
