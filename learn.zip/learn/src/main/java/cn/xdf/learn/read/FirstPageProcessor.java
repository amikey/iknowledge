package cn.xdf.learn.read;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;

import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;

/**
 * @author sunxingyang<br>
 */
public class FirstPageProcessor implements PageProcessor {

	private Site site = Site.me().setSleepTime(500).setRetryTimes(100)
			.setTimeOut(15000);
    static int index = 1;
	public void process(Page page) {
		String maincol = "//div[@class='g-kmf-wrapper']/div[@class='i-toefl-listen']/div[@class='g-clearfix']\n" + 
				"/div[@class='kmf-maincol']";
		//类别 例子：地理/环境/能源 (21)
		String category = page
				.getHtml()
				.xpath(maincol+"/div[@class='wrap-left-top new-list-left g-mod-shadow']/div[2]/ul[1]/li["+index+"]/a[1]/text()").toString();
		//每种类型的数量
		int qNum = Integer.parseInt(category.substring(category.indexOf("(")+1, category.indexOf(")")));
		// 阅读试题链接
		StringBuffer readLinks = new StringBuffer();
		for (int i = 1; i <= qNum; i++) {
			readLinks.append(page
					.getHtml()
					.xpath(maincol+"/div[@class='wrap-content-list']/div[@class='box-wrap-content']\n" + 
							"/div[@class='box-items clearfix']/div[@class='contents-box clearfix']/div["+i+"]\n" + 
							"/div[@class='boxs-scroll']/p[1]/a[1]/@href")
					.toString());
			readLinks.append(",");
		}
		System.out.println(category);
		String[] ss= readLinks.toString().split(",");
		for (String string : ss) {
			Spider.create(new SecondPageProcessor())
			.addUrl(string).run();
		}
		

	}

	public Site getSite() {
		return site;

	}

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		for (int i = 1; i <= 7; i++) {
			Spider.create(new FirstPageProcessor())
			.addUrl("http://toefl.kaomanfen.com/read/tpo?t=tpo&c=2&s="+i).run();
			index++;
		}
		System.out.println("爬取用时：" + (System.currentTimeMillis() - startTime)
				/ 1000 / 60 + "分");

	}

	/**
	 * 下载并保存MP3文件
	 * 
	 * @param mp3Url
	 */
	public static boolean downloadVioce(String mp3Url) {

		InputStream in = null;
		FileOutputStream f = null;
		try {
			// 经验证第一次请求MP3时 需要在地址后加入单词 即 变量 mp3Url
			in = new URL(mp3Url).openConnection().getInputStream(); // 创建连接、输入流
			// 创建文件输出流 重置MP3 文件名称 文件格式为 dict_单词.mp3
			/*
			 * File file = new File("E:/iknowledgeVoice/"+mp3Name+".mp3");
			 * if(!file.exists()){ file.mkdir(); }
			 */
			String[] mp3Names = mp3Url.split("/");

			File f1 = new File("E:/考满分音频/" + mp3Names[mp3Names.length - 1]);
			System.out.println(mp3Names[mp3Names.length - 1]);
			// f1.mkdirs();
			f = new FileOutputStream(f1);
			byte[] bb = new byte[1024]; // 接收缓存
			int len;
			while ((len = in.read(bb)) > 0) { // 接收
				f.write(bb, 0, len); // 写入文件
			}
			f.close();
			in.close();

		} catch (Exception e) {
			System.out.println(mp3Url);
			e.printStackTrace();
		} finally {
			try {
				if (f != null) {
					f.close();
				}
				if (in != null) {
					in.close();
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
		return true;
	}
}
