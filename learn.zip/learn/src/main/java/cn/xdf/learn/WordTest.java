package cn.xdf.learn;

import java.util.Date;

public class WordTest {
	private Integer id;
	private String testName;
	private Integer testBookId;
	private String testBook;
	private String teacherCode;
	private String teacherName;
	private Integer timuNum;
	private Integer startNum;
	private Integer endNum;
	private Date endTime;
	private Date createTime;
	private Date updateTime;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	
	public String getTestName() {
		return testName;
	}
	public void setTestName(String testName) {
		this.testName = testName;
	}
	public Integer getTestBookId() {
		return testBookId;
	}
	public void setTestBookId(Integer testBookId) {
		this.testBookId = testBookId;
	}
	public String getTestBook() {
		return testBook;
	}
	public void setTestBook(String testBook) {
		this.testBook = testBook;
	}
	public String getTeacherCode() {
		return teacherCode;
	}
	public void setTeacherCode(String teacherCode) {
		this.teacherCode = teacherCode;
	}
	public String getTeacherName() {
		return teacherName;
	}
	public void setTeacherName(String teacherName) {
		this.teacherName = teacherName;
	}
	
	public Integer getTimuNum() {
		return timuNum;
	}
	public void setTimuNum(Integer timuNum) {
		this.timuNum = timuNum;
	}
	
	public Integer getStartNum() {
		return startNum;
	}
	public void setStartNum(Integer startNum) {
		this.startNum = startNum;
	}
	public Integer getEndNum() {
		return endNum;
	}
	public void setEndNum(Integer endNum) {
		this.endNum = endNum;
	}
	public Date getEndTime() {
		return endTime;
	}
	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	
}
