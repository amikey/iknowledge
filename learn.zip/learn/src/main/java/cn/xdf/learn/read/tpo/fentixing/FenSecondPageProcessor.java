package cn.xdf.learn.read.tpo.fentixing;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import cn.xdf.learn.read.StreamTool;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.selector.Html;

/**
 * @author sunxingyang<br>
 */
public class FenSecondPageProcessor implements PageProcessor {

	private Site site = Site.me().setSleepTime(500).setRetryTimes(100)
			.setTimeOut(15000);

	public void process(Page page) {
		String form = page.getHtml().$("form#practiseForm").toString();
		String action = page.getHtml().$("form", "action").toString();
	/*	StringBuffer acc = new	StringBuffer();
		acc.append("http://toefl.kaomanfen.com/"+action+"?");
		List<String> lid = page.getHtml().$("form#practiseForm").$("input").all();
		for (String string : lid) {
			String value = Html.create(string).$("input","value").toString();
			String name = Html.create(string).$("input","name").toString();
			acc.append(name+"=");
			acc.append(value+"&");
		}
		System.out.println(acc.substring(0,acc.length()-1));
		Spider.create(new FenSecondPageProcessor())
		.addUrl(acc.substring(0,acc.length()-1))
		.run();*/
		try {
			System.out.println(getAll(action, form));
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public Site getSite() {
		return site;

	}

	public static void main(String[] args) {
		long startTime = System.currentTimeMillis();
		Spider.create(new FenSecondPageProcessor())
				.addUrl("http://toefl.kaomanfen.com/reading/pre?id=447&mode=sheet_reading")
				.run();
		System.out.println("爬取用时：" + (System.currentTimeMillis() - startTime)
				/ 1000 / 60 + "分");

	}

	public String getAll(String action, String form) throws Exception {
		
		String ac = "";
		URL url = new URL("http://toefl.kaomanfen.com" + action);
//		System.out.println("------------------------http://toefl.kaomanfen.com" + action);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		conn.setRequestMethod("POST");// 提交模式
		conn.setDoOutput(true);// 是否输入参数
		conn.setRequestProperty("User-Agent", "Mozilla/4.0 (compatible; MSIE 5.0; Windows NT; DigExt)");
		StringBuffer params = new StringBuffer();
		params.append(form);
		byte[] bypes = params.toString().getBytes();
		conn.getOutputStream().write(bypes);// 输入参数
		InputStream inStream = conn.getInputStream();
		ac = Html
				.create(new String(StreamTool.readInputStream(inStream),"utf-8")).$("form", "action").toString();
		if (ac.endsWith(",0.html")) {
			return "http://toefl.kaomanfen.com/" + ac;
		} else {
			return getAll(ac, form);
		}
	}
}
